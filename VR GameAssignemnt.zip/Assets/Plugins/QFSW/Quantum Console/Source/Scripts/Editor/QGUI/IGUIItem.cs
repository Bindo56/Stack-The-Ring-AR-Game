﻿namespace QFSW.QC.QGUI
{
    public interface IGUIItem
    {
        void DrawGUI(LayoutController layout);
    }
}