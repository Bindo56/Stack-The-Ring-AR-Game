﻿namespace QFSW.QC
{
    /// <summary>
    /// Sort order options.
    /// </summary>
    public enum SortOrder
    {
        Ascending = 0,
        Descending = 1
    }
}